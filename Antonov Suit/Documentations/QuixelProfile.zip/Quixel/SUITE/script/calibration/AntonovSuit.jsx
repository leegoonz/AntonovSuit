﻿#include common/functions.jsx

// Exports maps for Antonov Suit (UE4/Disney BRDF)
// Creates an RGB map: Metalness (R), Roughness (G), Ambient Occlusion (B)
// Stores Opacity in RGB alpha

function Calibrate()
{
    SetSaveAlpha(false);
    var mapType = GetMapType();
    switch(mapType)
    {
        case "Normal":
			SetMapType("Norm");
            var normal = GetBumpedNormal(mapType);
            return normal;
  
        case "AlbedoM":
            SetMapType("Color");
            return GetMergedMap();	

		case "Albedo":
            SetMapType("Diff");
            return GetMergedMap();

		case "Specular":
			SetMapType("Spec");
			return GetMergedMap();					
   
        case "Gloss":
            SetMapType("Rgb");
            var rgb = GetMergedMap();
			
			ApplyGGXCurve(false);
			Invert();
            
            var channels = rgb.channels;
            StoreActiveMapInChannel(rgb, channels, 1);
            StoreMapInChannel(rgb, "Metalness", channels, 0);
            StoreMapInChannel(rgb, "AO", channels, 2);
            AddAlphaMap(rgb, "Opacity");
            return rgb;
            
        case "Opacity":
		case "Bump":
        case "Metalness":
        case "AO":
        case "Height":
            return null;
            
        default:
            return GetMergedMap();
    }
}

function Finish()
{
    
}